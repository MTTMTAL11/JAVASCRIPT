﻿//silme pop
// index vererek silme splice
// ekleme push
//Yazdırmak için direk listenin adı
//index bulma indexof

let kullaniciAdlari = [];
let departmanlar = [];
let maaslar = [];
let calismaSüreleri = [];

function elemanEkle() {
    let anm = document.getElementById("anime");
    let resim = document.getElementById("resimID");

    if (anm.className == "ekleAnimasyon") {
        anm.className = "deneme10";
        resim.src = "resimler/tik1.png";
    }
    else if (anm.className == "deneme10") {
        anm.className = "ekleAnimasyon";
        resim.src = "resimler/tik1.png";    
    }
    else {

    }


    let deger = "";
    kullaniciAdlari.push(document.getElementById("kullanici_adi").value);
    if (document.getElementById("imalat_radio").checked == true) {
        deger = "İmalat";
    }
    else if (document.getElementById("it_radio").checked == true) {
        deger = "IT";
    }
    else if (document.getElementById("ik_radio").checked == true) {
        deger = "İnsan Kaynakları";
    }
    else if (document.getElementById("depo_radio").checked == true) {
        deger = "Depo";
    }
    departmanlar.push(deger);
    maaslar.push(document.getElementById("maas_girdi").value);
    calismaSüreleri.push(document.getElementById("calisma_süresi").value);
    //document.getElementById("departman_yazdir").innerHTML = deger;
}
function sil() {
    let gelenDeger = document.getElementById("kullanici_adi").value;
    let index;
    let anm = document.getElementById("anime");
    let resim = document.getElementById("resimID");
    if (anm.className == "ekleAnimasyon") {
        anm.className = "deneme10";
        resim.src = "resimler/carpi.png";

    }
    else if (anm.className == "deneme10") {
        anm.className = "ekleAnimasyon";
        resim.src = "resimler/carpi.png";
    }
    else {

    }
    if (kullaniciAdlari.indexOf(gelenDeger) != -1) {
        index = kullaniciAdlari.indexOf(gelenDeger);

        kullaniciAdlari.splice(index, 1);
        maaslar.splice(index, 1);
        departmanlar.splice(index, 1);
        calismaSüreleri.splice(index, 1);
    }
    else {

    }
    //document.getElementById("departman_yazdir").innerHTML = index;
}
function güncelle() {
    let gelenDeger = document.getElementById("kullanici_adi").value;
    let index;
    let deger = "";
    let anm = document.getElementById("anime"); 
    let resim = document.getElementById("resimID");
    if (anm.className == "ekleAnimasyon") {
        anm.className = "deneme10";
        resim.src = "resimler/guncelleme.png";

    }
    else if (anm.className == "deneme10") {
        anm.className = "ekleAnimasyon";
        resim.src = "resimler/guncelleme.png";
    }
    else {

    }
    if (kullaniciAdlari.indexOf(gelenDeger) != -1) {

        index = kullaniciAdlari.indexOf(gelenDeger);
        
        if (document.getElementById("imalat_radio").checked == true) {
            deger = "İmalat";
        }
        else if (document.getElementById("it_radio").checked == true) {
            deger = "IT";
        }
        else if (document.getElementById("ik_radio").checked == true) {
            deger = "İnsan Kaynakları";
        }
        else if (document.getElementById("depo_radio").checked == true) {
            deger = "Depo";
        }
        kullaniciAdlari[index] = document.getElementById("kullanici_adi").value;
        maaslar[index] = document.getElementById("maas_girdi").value;
        calismaSüreleri[index] = document.getElementById("calisma_süresi").value;
        departmanlar[index] = deger;

    }
    else {

    }
}
function goster() {
    let anm = document.getElementById("anime");
    let resim = document.getElementById("resimID");
    if (anm.className == "ekleAnimasyon") {
        anm.className = "deneme10";
        resim.src = "resimler/se1.png";

    }
    else if (anm.className == "deneme10") {
        anm.className = "ekleAnimasyon";
        resim.src = "resimler/se1.png";
    }
    else {

    }
    document.getElementById("kullanici_yazdir").innerHTML = "Kullanıcı Adı: " + kullaniciAdlari;
    document.getElementById("departman_yazdir").innerHTML = "Departman: " + departmanlar;
    document.getElementById("maas_yazdir").innerHTML = "Maaş: " + maaslar;
    document.getElementById("calisma_yazdir").innerHTML = "Çalışma Saati: " + calismaSüreleri;
}
