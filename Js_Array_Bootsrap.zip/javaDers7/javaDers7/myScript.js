﻿let urunAdlari = [];
let urunFiyatlari = [];
let urunKodlari = [];
let urunBedenleri = [];
let urunTurleri = [];

function UrunEkleme() {
    let urunAdi = document.getElementById("urun_adi");
    let urunFiyat = document.getElementById("urun_fiyati");
    let urunKodu = document.getElementById("urun_kodu");
    let beden;
    let sonFiyat;
    let urunTuru = document.getElementById("urun_resim").selectedIndex;
    let tur;

    if (urunTuru == 0) {
        tur = "Çorap";
    }
    else if (urunTuru == 1) {
        tur = "T-shirt";
    }
    else if (urunTuru == 2) {
        tur = "Ayakkabı";
    }
    else if (urunTuru == 3) {
        tur = "Pantolon";
    }
    urunTurleri.push(tur);
    urunAdlari.push(urunAdi.value);
    urunKodlari.push(urunKodu.value);
    if (document.getElementById("radio_l").checked) {
        beden = "L";
    }
    else if (document.getElementById("radio_m").checked) {
        beden = "M";
    }
    else if (document.getElementById("radio_s").checked) {
        beden = "S";
    }
    urunBedenleri.push(beden);

    if (document.getElementById("radio_pesin").checked) {
        sonFiyat = parseInt(urunFiyat.value) * 0.9;
    }
    else if (document.getElementById("radio_taksit").checked) {
        sonFiyat = urunFiyat.value;
    }
    urunFiyatlari.push(sonFiyat);
    
}

function UrunGoster() {
    let sayac = urunFiyatlari.length;
    let index;
    for (let i = 0; i < sayac; i++) {
        if (document.getElementById("urun_adi").value == urunAdlari[i]) {
            index = i;
            break;
        }
    }
    if (urunTurleri[index] == "Çorap") {
        document.getElementById("resim_yazdir").src = "resimler/corapPNG.png";
    }
    else if (urunTurleri[index] == "T-shirt") {
        document.getElementById("resim_yazdir").src = "resimler/tshirtPNG.png";
    }
    else if (urunTurleri[index] == "Ayakkabı") {
        document.getElementById("resim_yazdir").src = "resimler/ayakkabiPNG.png";
    }
    else if (urunTurleri[index] == "Pantolon") {
        document.getElementById("resim_yazdir").src = "resimler/pantolonPNG.png";
    }

    document.getElementById("fiyat_yazdir").innerHTML = "Fiyat: " + urunFiyatlari[index];
    document.getElementById("kod_yazdir").innerHTML = "Kod: " + urunKodlari[index];
    document.getElementById("beden_yazdir").innerHTML = "Beden: " + urunBedenleri[index];
    document.getElementById("tur_yazdir").innerHTML = urunAdlari[index];

}