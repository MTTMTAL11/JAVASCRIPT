var sayi=0;
var secim="";
var eskiSayi="";
function sayiEkle(gSayi){
        if(sayi=="0"){
            sayi=gSayi;
        }
        else{
            sayi+=gSayi;
        }
        document.getElementById("sayi").innerText=sayi;
}


function yuzdeAl(){
    var sonuc = parseFloat(sayi)
}

function isaretDegistir(){
    sayi=sayi*-1;
    document.getElementById("sayi").innerText=sayi;
}

function sil(){
    eskiSayi=sayi.toString();
    sayi="";
    for(var i=0;i<eskiSayi.length-1;i++){
        sayi+=eskiSayi[i];
    }
    if(sayi==""){
        sayi="0"
    }
    document.getElementById("sayi").innerText=sayi;

}

function sifirla(){
    document.getElementById("sayi").innerText="0";
    document.getElementById("islem").innerText="";
    sayi="0";
    eskiSayi="0";
    secim="";
}

function noktaEkleme(){
    var noktaKontrol=0;
    for(var i=0;i<sayi.length;i++ ){
        if(sayi[i]=="."){
            noktaKontrol=1;
        }
    }
    if(noktaKontrol==0){
        sayi+=".";
        document.getElementById("sayi").innerText=sayi;
    }
}

function hesaplama(){
    if(secim!=""){
        if(secim=="+"){
            document.getElementById("islem").innerText=eskiSayi.toString()+"+"+sayi.toString()+"=";
            sayi=parseFloat(eskiSayi)+parseFloat(sayi);
            document.getElementById("sayi").innerText=sayi;
        }
        else if(secim=="-"){
            document.getElementById("islem").innerText=eskiSayi.toString()+"-"+sayi.toString()+"=";
            sayi=parseFloat(eskiSayi)-parseFloat(sayi);
            document.getElementById("sayi").innerText=sayi;
        }
        else if(secim=="/"){
            document.getElementById("islem").innerText=eskiSayi.toString()+"/"+sayi.toString()+"=";
            sayi=parseFloat(eskiSayi)/parseFloat(sayi);
            document.getElementById("sayi").innerText=sayi;
        }
        else if(secim=="*"){
            document.getElementById("islem").innerText=eskiSayi.toString()+"*"+sayi.toString()+"=";
            sayi=parseFloat(eskiSayi)*parseFloat(sayi);
            document.getElementById("sayi").innerText=sayi;
        }
        else if(secim=="%"){
            document.getElementById("islem").innerText=eskiSayi.toString()+"%"+sayi.toString()+"=";
            sayi=parseFloat(eskiSayi)*parseFloat(sayi)/100;
            document.getElementById("sayi").innerText=sayi;
        }
        secim="";
        eskiSayi="";
    }
}

function islemBasma(sec){
if(sec=="+"){
    secim="+";
}
else if(sec=="-"){
    secim="-";
}
else if(sec=="%"){
    secim="%";
}
else if(sec=="*"){
    secim="*";
}
else if(sec=="/"){
    secim="/";
}
eskiSayi=sayi;
sayi="0";
document.getElementById("islem").innerText=eskiSayi+secim;
document.getElementById("sayi").innerText=sayi;
}