var ad,soyad,ePosta,sifre,dTarihi,cinsiyet,sehir,cepTelefonu,kabul;

var isimler = [];
var soyisimler = [];
var ePostalar = [];
var sifreler = [];
var dTarihleri = [];
var cinsiyetler = [];
var sehirler = [];
var cepTelefonlari=[];

function bosKontrol(){
    ad = document.getElementById("input-ad").value;
    soyad = document.getElementById("input-soyad").value;
    ePosta =  document.getElementById("input-eposta").value;
    sifre = document.getElementById("input-sifre").value;
    dTarihi = document.getElementById("input-dogumTarihi").value;
    sehir = document.getElementById("input-sehir").value;
    cepTelefonu =  document.getElementById("input-cepTelefonu").value;
    if(document.getElementById("input-kadin").checked==true){
        cinsiyet="kadın";
    }
    else{
        if(document.getElementById("input-erkek").checked==true){
            cinsiyet="erkek";
        }
        else{
            cinsiyet="";
        }
    }

    if(document.getElementById("input-kabul").checked){
        kabul=true;
    }
    else{
        kabul=false;
    }
    
    if(ad=="" || soyad=="" || ePosta=="" || dTarihi==""  || cinsiyet==""  || sehir==""  || cepTelefonu==""  || kabul==false  || sifre==""){
        return false;
    }
    return true;
}

function cepTelefonuKontrol(){
    if(cepTelefonlari.indexOf(cepTelefonu)==-1){
        return true;
    }
    return false;
}

function ekleme(){
    if(bosKontrol()){
        if(cepTelefonuKontrol()){
            isimler.push(ad);
            soyisimler.push(soyad);
            ePostalar.push(ePosta);
            sifreler.push(sifre);
            dTarihleri.push(dTarihi);
            cinsiyetler.push(cinsiyet);
            sehirler.push(sehir);
            cepTelefonlari.push(cepTelefonu);
            alert("Kişi Eklendi!");
            temizleme();
        }
        else{
            alert("Bu Cep Telefonuna Kayıtlı Bir Kişi Var!")
        }
    }
    else{
        alert("Lütfen Formdaki Tüm Alanları Doldurunuz!");
    }
}


function temizleme(){
    document.getElementById("input-ad").value="";
    document.getElementById("input-soyad").value="";
    document.getElementById("input-eposta").value="";
    document.getElementById("input-sifre").value="";
    document.getElementById("input-dogumTarihi").value="";
    document.getElementById("input-sehir").value="";
    document.getElementById("input-cepTelefonu").value="";
    document.getElementById("input-kadin").checked=false;
    document.getElementById("input-erkek").checked=false;
    document.getElementById("input-kabul").checked=false;

}

var telNo;
function arama(){
    telNo=document.getElementById("input-arama").value;
    var index = cepTelefonlari.indexOf(telNo);
    if(index==-1){
        alert("Aradığınız Kişi Bulunamadı!");
    }
    else{
        alert("Aradığınız Kişi Bulundu!");
        document.getElementById("input-ad").value=isimler[index];
        document.getElementById("input-soyad").value=soyisimler[index];
        document.getElementById("input-eposta").value=ePostalar[index];
        document.getElementById("input-sifre").value=sifreler[index];
        document.getElementById("input-dogumTarihi").value=dTarihleri[index];
        document.getElementById("input-sehir").value=sehirler[index];
        document.getElementById("input-cepTelefonu").value=cepTelefonlari[index];
        if(cinsiyetler[index]=="erkek"){
            document.getElementById("input-kadin").checked=false;
        document.getElementById("input-erkek").checked=true;
        }
        else{
            document.getElementById("input-kadin").checked=true;
            document.getElementById("input-erkek").checked=false;
        }
        
        document.getElementById("input-kabul").checked=true;
    }
}

function guncelle(){
    var cinsiyet;
    if(document.getElementById("input-kadin").checked==true){
        cinsiyet="kadın";
    }
    else{
        if(document.getElementById("input-erkek").checked==true){
            cinsiyet="erkek";
        }
        else{
            cinsiyet="";
        }
    }
    var index;
    if(bosKontrol()){
        telNo = document.getElementById("input-arama").value;
        if(telNo==""){
            alert("Lütfen Güncellemek İstediğiniz Kişinin Telefon Numarasını Giriniz!");
        }
        else{
            index = cepTelefonlari.indexOf(telNo);
            if(index==-1){
                alert("Güncellemek İstediğiniz Kişi Mevcut Değil!");
            }
            else{
               isimler[index] = document.getElementById("input-ad").value;
               soyisimler[index]= document.getElementById("input-soyad").value;
                ePostalar[index]=document.getElementById("input-eposta").value;
                sifreler[index]=document.getElementById("input-sifre").value;
                dTarihleri[index]=document.getElementById("input-dogumTarihi").value;
               sehirler[index]= document.getElementById("input-sehir").value;
                cepTelefonlari[index]=document.getElementById("input-cepTelefonu").value;
                cinsiyetler[index]=cinsiyet;
                alert("Güncelleme Başarılı!");
                temizleme();
            }
        }
    }
    else{
        alert("Lütfen Güncelleme Yapmak İçi Tüm Alanları Doldurunuz!")
    }
}


function sil(){
    telNo = document.getElementById("input-arama").value;
    var index=cepTelefonlari.indexOf(telNo);
        if(telNo==""){
            alert("Lütfen Silmek İstediğiniz Kişinin Telefon Numarasını Giriniz!");
        }
        else{
            if(index==-1){
                alert("Silmek İstediğiniz Kişi Mevcut Değil!");
            }
            else{
                isimler.splice(index,1);
                soyisimler.splice(index,1);
                ePostalar.splice(index,1);
                sifreler.splice(index,1);
                dTarihleri.splice(index,1);
                cinsiyetler.splice(index,1);
                sehirler.splice(index,1);
                cepTelefonlari.splice(index,1);
                temizleme();
                document.getElementById("input-arama").value="";
                alert("Silme İşlemi Başarılı!");

            }
        }
}


function change(){
    var randomResim=Math.floor(Math.random()*6);
document.getElementsByTagName("body")[0].style.backgroundImage="url(resim"+randomResim+".jpg)";
    setInterval(resimDegis,2000);
    document.getElementsByTagName("div")[0].style.animation="renkDegisme2 5s infinite";
}

var resimDegis=function (){
var randomResim=Math.floor(Math.random()*6);
document.getElementsByTagName("body")[0].style.backgroundImage="url(resim"+randomResim+".jpg)";
};